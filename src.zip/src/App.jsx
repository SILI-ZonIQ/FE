import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Monitoring from "./pages/Monitoring";
import Bump from "./pages/Bump";

function App() {

  // 범프창 상태
  const [bumpData, setBumpData] = useState(null);

  // 테스트용 위험 이벤트 발생
  useEffect(() => {

    // 5초 후 자동으로 위험 감지 팝업 띄우기
    const timer = setTimeout(() => {
      setBumpData({
        zone: "위험 구역 A-01",
        worker: "작업자 2명 감지",
        time: new Date().toLocaleString(),
        severity: "HIGH"
      });
    }, 5000);

    return () => clearTimeout(timer);

  }, []);

  // 무시 버튼
  const handleIgnore = () => {
    setBumpData(null);
  };

  // 긴급 정지 버튼
  const handleEmergencyStop = () => {

    alert("긴급 정지가 실행되었습니다.");

    setBumpData(null);

    // 여기서 나중에 FastAPI나 PLC API 연결 가능
    // fetch("http://localhost:8000/emergency-stop")

  };

  return (
    <Router>

      {/* 전역 범프창 */}
      <Bump
        data={bumpData}
        onIgnore={handleIgnore}
        onEmergencyStop={handleEmergencyStop}
      />

      <Routes>

        <Route path="/" element={<Login />} />

        <Route
          path="/dashboard"
          element={<Dashboard />}
        />

        <Route
          path="/monitoring"
          element={<Monitoring />}
        />

      </Routes>

    </Router>
  );
}

export default App;