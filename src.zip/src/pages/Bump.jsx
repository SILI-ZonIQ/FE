import '../css/Bump.css';

const IconWarning = () => <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#f61115" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;

const Bump = ({ data, onIgnore, onEmergencyStop }) => {
  if (!data) return null;

  return (
    <div className="bump-overlay">
      <div className="bump-modal">
        <div className="bump-header">
          <IconWarning />
          <h2>위험 구역 침입 감지</h2>
        </div>
        <div className="bump-body">
          <div className="bump-info-row">
            <span className="label">발생 위치</span>
            <span className="value highlight">{data.zone}</span>
          </div>
          <div className="bump-info-row">
            <span className="label">감지 대상</span>
            <span className="value">{data.worker}</span>
          </div>
          <div className="bump-info-row">
            <span className="label">감지 시간</span>
            <span className="value">{data.time}</span>
          </div>
          <div className="bump-info-row">
            <span className="label">위험 등급</span>
            <span className="value critical">{data.severity}</span>
          </div>
        </div>
        <div className="bump-footer">
          <button className="btn-ignore" onClick={onIgnore}>무시</button>
          <button className="btn-emergency-action" onClick={onEmergencyStop}>긴급 정지 실행</button>
        </div>
      </div>
    </div>
  );
};

export default Bump;